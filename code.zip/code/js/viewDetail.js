/**
 * Created by 95 on 2016/11/24.
 */

/**
 * 绘制canvas
 * @param rectX
 * @param rectY
 */
function addCanvas(ctx,rectX, rectY) {
    rectX = 0;
    rectY = 0;

    //绘制矩形区域
    ctx.strokeStyle = "gray";
    ctx.lineWidth = 0.5;
    ctx.strokeRect(rectX,rectY,400,284);

    //绘制图片
    var img = new Image();
    img.src = "http://192.168.88.3:8074/static/img/edit.png";
    img.onload = function () {
        ctx.drawImage(img,rectX+30,rectY+30,30,30);
    }

    //绘制文字
    ctx.font="16px Arial";//定义字体样式
    ctx.fillText("问",rectX+70,rectY+50)

    //绘制图片
    var img = new Image();
    img.src = "http://192.168.88.3:8074/static/img/edit.png";
    img.onload = function () {
        ctx.drawImage(img,rectX+30,rectY+80,30,30);
    }

    //绘制文字
    ctx.font="16px Arial";//定义字体样式
    ctx.fillText("答",rectX+70,rectY+100)

    //绘制图片
    var img = new Image();
    img.src = "http://192.168.88.3:8074/static/img/edit.png";
    img.onload = function () {
        ctx.drawImage(img,rectX+70,rectY+160,30,30);
    }

    //绘制文字
    ctx.font="16px Arial";//定义字体样式
    ctx.fillText("保存",rectX+115,rectY+182)

    //绘制图片
    var img = new Image();
    img.src = "http://192.168.88.3:8074/static/img/edit.png";
    img.onload = function () {
        ctx.drawImage(img,rectX+220,rectY+160,30,30);
    }

    //绘制文字
    ctx.font="16px Arial";//定义字体样式
    ctx.fillText("删除",rectX+265,rectY+182)

    //绘制图片
    var img = new Image();
    img.src = "http://192.168.88.3:8074/static/img/edit.png";
    img.onload = function () {
        ctx.drawImage(img,rectX+70,rectY+220,30,30);
    }

    //绘制文字
    ctx.font="16px Arial";//定义字体样式
    ctx.fillText("添加子节点",rectX+115,rectY+242)

    //绘制图片
    var img = new Image();
    img.src = "http://192.168.88.3:8074/static/img/edit.png";
    img.onload = function () {
        ctx.drawImage(img,rectX+220,rectY+220,30,30);
    }

    //绘制文字
    ctx.font="16px Arial";//定义字体样式
    ctx.fillText("删除所有子节点",rectX+265,rectY+242)
}

function setEventListener(index){
    var detail_canvas = document.getElementById("item_canvas_"+ index +"")
    //设置鼠标移动的事件
    detail_canvas.onmousemove = function (e) {
        e = e||event;//获取事件对象
        //获取事件在canvas中发生的位置
        var x = e.clientX - detail_canvas.offsetLeft + scrollLeft;
        var y = e.clientY - detail_canvas.offsetTop + scrollTop;
        //如果事件位置在矩形区域中
        for(var i = 0;i < canvasItemBtLocation.length;i++){
            var rectSave = canvasItemBtLocation[i].rectSave;
            var rectDelete = canvasItemBtLocation[i].rectDelete;
            var rectAdd = canvasItemBtLocation[i].rectAdd;
            var rectDelAll = canvasItemBtLocation[i].rectDelAll;
            if(x >= rectSave.x && x <= rectSave.x + rectSave.w && y>= rectSave.y && y <= rectSave.y + rectSave.h){
                //保存
                $("#item_canvas_"+ index +"").css("cursor","pointer");
            }else if(x >= rectDelete.x && x <= rectDelete.x + rectDelete.w && y>= rectDelete.y && y <= rectDelete.y + rectDelete.h){
                //删除
                $("#item_canvas_"+ index +"").css("cursor","pointer");
            }else if(x >= rectAdd.x && x <= rectAdd.x + rectAdd.w && y>= rectAdd.y && y <= rectAdd.y + rectAdd.h){
                //添加子节点
                $("#item_canvas_"+ index +"").css("cursor","pointer");
            }else if(x >= rectDelAll.x && x <= rectDelAll.x + rectDelAll.w && y>= rectDelAll.y && y <= rectDelAll.y + rectDelAll.h){
                //删除所有的子节点
                $("#item_canvas_"+ index +"").css("cursor","pointer");
            }else{
                //$("#item_canvas_"+ index +"").css("cursor","auto");
            }
        }
    }

    var cindex = index
    //设置点击事件
    detail_canvas.onclick = function (e) {
        e = e||event;//获取事件对象
        //获取事件在canvas中发生的位置
        var x = e.clientX - detail_canvas.offsetLeft + scrollLeft;
        var y = e.clientY - detail_canvas.offsetTop + scrollTop;
        isClick = true;
        for(var i = 0;i < canvasItemBtLocation.length;i++) {
            var rectSave = canvasItemBtLocation[i].rectSave;
            var rectDelete = canvasItemBtLocation[i].rectDelete;
            var rectAdd = canvasItemBtLocation[i].rectAdd;
            var rectDelAll = canvasItemBtLocation[i].rectDelAll;
            //var ctx = detail_canvas.getContext("2d");
            //ctx.beginPath();
            //如果事件位置在矩形区域中
            if (x >= rectSave.x && x <= rectSave.x + rectSave.w && y >= rectSave.y && y <= rectSave.y + rectSave.h) {
                //保存,获取input中的值，传给服务器
                var question = $("#item_div_" + cindex + "").children("input").eq(0).val();
                var answer = $("#item_div_" + cindex + "").children("input").eq(1).val();
                console.log('question = ' + question + ",answer = " + answer);
                //TODO
                console.log("保存")
            } else if (x >= rectDelete.x && x <= rectDelete.x + rectDelete.w && y >= rectDelete.y && y <= rectDelete.y + rectDelete.h) {
                //删除
                console.log("删除");

                var removeContainer = $("#item_div_"+ cindex +"").find("div");
                if(removeContainer.length > 0){
                    for(var i = 0;i < removeContainer.length;i++){
                        idIndexContainer = $.grep(idIndexContainer, function (value) {
                            return value.currIndex != removeContainer.eq(i).attr("id").substring(9);
                        });
                    }
                }

                idIndexContainer = $.grep(idIndexContainer, function (value) {
                    return value.currIndex != cindex;
                });

                $("#item_div_"+ cindex +"").remove();

                //刷新
                refreshCanvas();

            } else if (x >= rectAdd.x && x <= rectAdd.x + rectAdd.w && y >= rectAdd.y && y <= rectAdd.y + rectAdd.h) {
                if (isClick) {
                    //添加子节点,再次绘制
                    console.log("添加子节点")
                    //1.添加div子节点
                    //1.1计算id
                    var currIndex = cindex + "_" + ($("#item_div_"+ cindex +"").children("div").length + 1);
                    $("#item_div_"+ cindex +"").append("<div id=\"item_div_"+ currIndex +"\"><canvas id=\"item_canvas_"+ currIndex +"\"></canvas>" +
                        "<input type=\"text\" value=\"\"><input type=\"text\" value=\"\"></div>");
                    //1.2将id保存到集合中
                    var id = parseInt(currIndex.substring(2).replace("_",""));
                    idIndexContainer.push({"id":id,"parentIndex":cindex,"currIndex":currIndex});

                    //刷新
                    refreshCanvas();
                }
            } else if (x >= rectDelAll.x && x <= rectDelAll.x + rectDelAll.w && y >= rectDelAll.y && y <= rectDelAll.y + rectDelAll.h) {
                //删除所有的子节点
                console.log("删除所有的子节点")
                var removeContainer = $("#item_div_"+ cindex +"").find("div");

                if(removeContainer.length > 0){
                    for(var i = 0;i < removeContainer.length;i++){
                        idIndexContainer = $.grep(idIndexContainer, function (value) {
                            return value.currIndex != removeContainer.eq(i).attr("id").substring(9);
                        });
                    }
                }

                $("#item_div_"+ cindex +"").find("div").remove();

                //刷新
                refreshCanvas();
            }
        }
    }
}

/**
 * 获得Div的宽带
 * @param index
 */
function getDivWidth(index){
    //1.查找改节点下所有的div元素
    var allChildContainer = $("#item_div_"+ index +"").find("div");
    //2.组成数组[1,11,12,111,112,113,121,122,1111,1112,1113,1121,1122]
    var idAttr = [];
    for(var i = 0;i < allChildContainer.length;i++){
        var id = allChildContainer.eq(i).attr("id").substring(11);
        idAttr.push(id)
    }
    var num = 0;
    var rootNum = 0;
    //3.遍历数组，移出前面一样的
    console.log(idAttr);
    var rootIdAttr = [];
    for(var i = 0;i < idAttr.length;i++){
        var currId = idAttr[i];
        for(var j = 0;j < idAttr.length;j++){
            if(idAttr[j].indexOf(currId) == 0 ){
                console.log("idAttr[i] == "+idAttr[i])
                num++;
            }
        }
        if(num < 2){
            rootNum++;
            console.log("rootNum = "+rootNum);
        }
        num = 0;
    }
    //4.计算宽度
    console.log(index+","+rootNum)
    return rootNum*400+(rootNum-1)*200;
}

/**
 * 获得当前节点的层次的个数
 * @param idIndex
 */
function getLevelNum(idIndex){
    var levelNum = 0;
    if( $("#item_div_"+idIndex+"").find("div").length > 0){
        //找到最深的一层
        var divContainer = $("#item_div_"+idIndex+"").find("div");
        var maxId = "item_div";
        for(var i =0;i< divContainer.length;i++){
            var id = divContainer.eq(i).attr("id").toString();
            if(id.length > maxId.length){
                maxId = id;
            }
        }

        var parentId = $("#item_div_"+idIndex+"").attr("id");

        //0_1_1_2_1 //0_1  3
        levelNum = maxId.substring(9).split("_").length - parentId.toString().substring(9).split("_").length + 1;
    }else{
        levelNum = 1;
    }

    return levelNum;
}

/**
 * 添加一个canvas子类
 */
function addCanvasItem(ctx,rectX,rectY,index) {

    //将按钮的位置保存
    canvasItemBtLocation.push({
        "rectSave":{x:rectX+70,y:rectY+160,w:80,h:30},
        "rectDelete":{x:rectX+220,y:rectY+160,w:80,h:30},
        "rectAdd":{x:rectX+70,y:rectY+220,w:125,h:30},
        "rectDelAll":{x:rectX+220,y:rectY+220,w:160,h:30},
    });

    addCanvas(ctx,rectX,rectY);

    setEventListener(index);
}

function refreshCanvas (){
    //2.重新计算每个节点的位置
    var parentIndex;
    var index = 0;
    var divML = 400;
    var divW = 400;
    var divH = 284;
    var canvasML = 0;
    var inputL = 105;
    //console.log(idIndexContainer)
    for(var i = 0;i<idIndexContainer.length;i++){
        var idIndex = idIndexContainer[i].currIndex;
        parentIndex = idIndexContainer[i].parentIndex;

        var childNum = $("#item_div_"+ idIndex +"").children("div").length;
        var allChildNum = $("#item_div_"+ idIndex +"").find("div").length;

        if(idIndex == '0'){
            index = idIndex;
            divML = 400;
            divW = getDivWidth(index);
            var level = getLevelNum(idIndex);
            divH = level * 284 + (level - 1) * 100;
            //父div的width/2-200
            canvasML = divW/2 - 200;
            inputL = canvasML+105;
        }else{
            index = idIndex;
            if(childNum > 0){//有节点
                if(childNum == 1){
                    divW = 400;
                }else{
                    divW = getDivWidth(index);
                }
                divH = getLevelNum(idIndex) * 284 + (getLevelNum(idIndex)-1) * 100;
                if(divW == 400){
                    canvasML = 0;
                }else{
                    canvasML = (allChildNum ) * 300;
                }
                inputL = canvasML + 105;
            }else{//无节点
                //width: 400px;height: 284px;
                divW = 400;
                divH = 284;
                //父div无子div:<canvas width="400px" height="284px" id="item_canvas_0_x" style="cursor: auto;"></canvas>
                canvasML = 0;
                inputL = canvasML+105;
            }
            //margin-left:(前一个兄弟节点的width + margin-left) + 200(无兄弟就没有这个属性)
            if($("#item_div_"+ idIndex +"").prevAll("div").length > 0){
                divML = $("#item_div_"+ idIndex +"").prev("div").width() + parseInt($("#item_div_"+ idIndex +"").prev("div").css("marginLeft")) + 200 ;
            }else{
                divML = 0;
            }
        }

        //更新一次div
        $("#item_div_"+ index +"").css({"width":divW,"margin-left":divML,"height":divH});

        //添加,计算结果保存在数组中
        itemArgumentsContainer.push({"parentIndex":parentIndex,"index":index,"divML":divML,"divW":divW,"divH":divH,"canvasML":canvasML,"inputL":inputL});

    }

    //清空，重绘
    $("#canvas_container").html("");
    var canvas_basis = document.getElementById("canvas_basis");
    var basis_ctx = canvas_basis.getContext("2d");
    basis_ctx.clearRect(0,0,10000,10000);
    canvasItemBtLocation = [];
    for(var i = 0;i < itemArgumentsContainer.length;i++){
        var parentIndex = itemArgumentsContainer[i].parentIndex;
        var index = itemArgumentsContainer[i].index;
        var divML = itemArgumentsContainer[i].divML;
        var divW = itemArgumentsContainer[i].divW;
        var divH = itemArgumentsContainer[i].divH;
        var canvasML = itemArgumentsContainer[i].canvasML;
        var inputL = itemArgumentsContainer[i].inputL;
        if(i == 0){
            addRootItem(index,divML,divW,divH,canvasML,inputL);
        }else{
            addItem(parentIndex,index,divML,divW,divH,canvasML,inputL);
        }
        //绘制canvas
        var item_canvas = document.getElementById("item_canvas_"+ index +"");
        var currCtx = item_canvas.getContext("2d");
        addCanvas(currCtx,divML,100);
        //将按钮的位置保存(绝对位置)
        var rectX = $("#item_div_"+ index +"").offset().left;
        var rectY = $("#item_div_"+ index +"").offset().top;
        canvasItemBtLocation.push({
            "rectSave":{x:rectX+70,y:rectY+160,w:80,h:30},
            "rectDelete":{x:rectX+220,y:rectY+160,w:80,h:30},
            "rectAdd":{x:rectX+70,y:rectY+220,w:125,h:30},
            "rectDelAll":{x:rectX+220,y:rectY+220,w:160,h:30},
        });
        //设置click和move事件
        setEventListener(index);
    }
    itemArgumentsContainer = [];
}

var canvasItemContainer = [];
var canvasItemBtLocation = [];
var isClick = false;
var idIndexContainer = [];
var itemArgumentsContainer = [];

/**
 * 添加根节点
 * @param index
 * @param divML
 * @param divW
 * @param divH
 * @param canvasML
 * @param inputL
 */
function addRootItem(index,divML,divW,divH,canvasML,inputL){
    //canvas
    $("#canvas_container").append("<div style=\"margin-left: "+ divML +"px; margin-top: 100px; width: "+ divW +"px; height: "+ divH +"px;position:absolute;\" id=\"item_div_" + index + "\">" +
        "<canvas width=\"400px\" height=\"284px\" id=\"item_canvas_"+ index +"\" style=\"cursor: auto; margin-left: "+ canvasML +"px;\"></canvas>" +
        "<input type=\"text\" value=\"\" class=\"input_class\" style=\"left: "+ inputL +"px; top: 40px;\">" +
        "<input type=\"text\" value=\"\" class=\"input_class\" style=\"left: "+ inputL +"px; top: 90px;\"></div>");
}

/**
 * 添加子节点
 * @param index
 * @param divML
 * @param divW
 * @param divH
 * @param canvasML
 * @param inputL
 */
function addItem(parentIndex,index,divML,divW,divH,canvasML,inputL){
    //canvas
    $("#item_div_"+ parentIndex +"").append("<div style=\"float: left;width: "+ divW +"px;height: "+ divH +"px;position:absolute;margin-left:"+ divML +"px;margin-top:100px\" id=\"item_div_"+ index +"\">" +
        "<canvas width=\"400px\" height=\"284px\" id=\"item_canvas_"+ index +"\" style=\"cursor: auto;margin-left: "+ canvasML +"px;\"></canvas>" +
        "<input type=\"text\" value=\"\" class=\"input_class\" style=\"left: "+ inputL +"px; top: 40px;\">" +
        "<input type=\"text\" value=\"\" class=\"input_class\" style=\"left: "+ inputL +"px; top: 90px;\"></div>");

    //画出父级到子级的连接线
    var canvas_basis = document.getElementById("canvas_basis");
    var basis_ctx = canvas_basis.getContext("2d");
    basis_ctx.beginPath();//开始画笔
    var begin_left = $("#item_canvas_"+ parentIndex +"").offset().left+200;
    var begin_top = $("#item_canvas_"+ parentIndex +"").offset().top + 284;
    basis_ctx.moveTo(begin_left,begin_top);//移动到起点
    var end_left = $("#item_canvas_"+ index +"").offset().left + 200;
    var end_top = $("#item_canvas_"+ index +"").offset().top;;
    basis_ctx.lineTo(end_left,end_top);//终点
    basis_ctx.stroke();//描边

}

var scrollTop = 0;
var scrollLeft = 0;

$(function () {


    var index = 0;
    var divML = 400;
    var divW = 400;
    var divH = 284;
    var canvasML = 0;
    var inputL = 105;

    idIndexContainer.push({"id":0,"parentIndex":0,"currIndex":index+""});

    addRootItem(index,divML,divW,divH,canvasML,inputL);

    var item_canvas = document.getElementById("item_canvas_"+ index +"");
    var ctx = item_canvas.getContext("2d");
    var rectX = divML;
    var rectY = 100;

    addCanvasItem(ctx,rectX,rectY,index);
    canvasItemContainer.push({"ctx":ctx,"rectX":rectX,"rectY":rectY,"index":index})

    //绑定滚动事件
    $(document).scroll(function () {
        scrollTop = $(document).scrollTop();
        scrollLeft = $(document).scrollLeft();
    });

})
